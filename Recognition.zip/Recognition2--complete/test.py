import cv2
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

cap = cv2.VideoCapture(0)

while True :
    ret,frame= cap.read()

    if ret ==False:
        continue
    cv2.imshow("hello ",frame)
    key_pressed =cv2.waitKey(1) & 0xFF
    if key_pressed == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

